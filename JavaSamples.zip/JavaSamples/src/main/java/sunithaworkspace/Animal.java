package sunithaworkspace;
//polymorphism
public class Animal {
    public void sound() {
        System.out.println("animal is making sound");
    }

    public static void main(String args[]) {
        Animal obj = new Animal();
        obj.sound();
    }
}
