package sunithaworkspace;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;

//import java.util.List;
public class SeleniumPractice {
    WebDriver driver;


    public SeleniumPractice(WebDriver dr) {
        this.driver = dr;
    }

    public WebElement getName() {
    return driver.findElement(By.cssSelector("#form_78ea690540a24bd8b9dcfbf99e999fea"));

    }
}


        // CSS: input[name='username']

        //     "//.form-body > .form-row"));
        //return driver.findElement(By.cssSelector("#form_78ea690540a24bd8b9dcfbf99e999fea"));
        //".form-body > .form-row > .form-label"));



