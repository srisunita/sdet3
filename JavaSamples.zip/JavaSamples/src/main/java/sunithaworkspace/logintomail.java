package sunithaworkspace;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;

public class logintomail {

    public static void main(String args[]) throws Exception {
        WebDriver driver;
        System.setProperty("webdriver.chrome.driver", "C:/Users/16281/Downloads/chromedriver_win32/chromextract/chromedriver.exe");
        driver = new ChromeDriver();

        driver.get("http://www.javacodegeeks.com");
        WebElement element = driver.findElement(By.xpath("/html/body[@class='home blog gecko']/div[@id='wrapper']/div[@id='bottom']/div[1]/a[@class='ext-link']"));
        System.out.println(element.getText());
        System.out.println("Page Title is : " + driver.getTitle());
        driver.quit();
    }
}


