package sunithaworkspace;
import org.junit.Test;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

import java.util.Scanner;

public class CheckforEvenOddNumbers{


    public static void main(String[] args) {
      int num;
      System.out.println("enter an integer value");
       Scanner input = new Scanner(System.in);
      num = input.nextInt();
        if ( num % 2 == 0 )
            System.out.println("Entered number is even");
        else
            System.out.println("Entered number is odd");
    }

    @Test
    public void testSelenium(){
        System.setProperty("webdriver.chrome.driver", "C:/Users/16281/IdeaProjects/JavaSamples/src/main/resources/Selenium Drivers/chromedriver.exe");

        WebDriver driver = new ChromeDriver();
        driver.get("http://www.google.com");
    }
}


