package sunithaworkspace.pages;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;

public class SeleniumPracticeFormPage {

    WebDriver driver = new ChromeDriver();

    public SeleniumPracticeFormPage(WebDriver dr){
        this.driver = dr;
    }

    public WebElement getDragMeElement(){
        return driver.findElement(By.id("draga"));
    }

    public WebElement getDragToElement(){
        return driver.findElement(By.id("dragb"));
    }


    public WebElement getCSSElement() {

        return driver.findElement(By.cssSelector("div.wpb_wrapper > p > button[style='background-color:DarkGreen'][onclick='newBrwTab()']"));

    }
}
// '>' means one inside another
// '[]' has attribute name and value

