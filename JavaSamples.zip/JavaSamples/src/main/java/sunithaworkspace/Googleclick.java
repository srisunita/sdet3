package sunithaworkspace;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;

public class Googleclick {

    public static void main(String args[]) {
        WebDriver driver;
        System.setProperty("webdriver.chrome.driver", "C:/Users/16281/Downloads/chromedriver_win32/chromextract/chromedriver.exe");
        driver = new ChromeDriver();
        driver.get("https://www.google.com");
      //  Actions actions = new Actions(driver);
        WebElement el = driver.findElement(By.name("btnk"));
        String text = el.getText();
       // Assert.assertEquals("mytext", text);

        System.out.println(text);


    }

}
