package sunithaworkspace.testcases;
import org.apache.commons.io.FileUtils;
import org.junit.Assert;
import org.junit.Test;
import org.openqa.selenium.OutputType;
import org.openqa.selenium.TakesScreenshot;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.interactions.Actions;
import sunithaworkspace.SeleniumPractice;
import java.io.File;

public class LetsTalk {

    @Test
    public void sendEmailTest() throws Exception {
        System.setProperty("webdriver.chrome.driver", "C:/Users/16281/Downloads/chromedriver_win32/chromextract/chromedriver.exe");

        WebDriver driver = new ChromeDriver();
        driver.manage().window().maximize();
        driver.get("http://www.practiceselenium.com/let-s-talk-tea.html");

       Assert.assertEquals("Let's Talk Tea", driver.getTitle());

        System.out.print("Assertion Passed successfully");

        this.takeSnapShot(driver, "C://CaptureScreenshot//test.jpeg") ;

        SeleniumPractice spPage = new SeleniumPractice(driver);

        WebElement element = spPage.getName();

        String strng = element.getText();

         System.out.println(strng);

        Actions actions = new Actions(driver);
        actions.perform();

        //Get the current window handle
        String windowHandle = driver.getWindowHandle();
        System.out.println(windowHandle);
        }
     private void takeSnapShot(WebDriver webdriver,String fileWithPath) throws Exception{
        //Convert web driver object to TakeScreenshot

        TakesScreenshot scrShot =((TakesScreenshot)webdriver);

        //Call getScreenshotAs method to create image file

        File SrcFile=scrShot.getScreenshotAs(OutputType.FILE);

        //Move image file to new destination

        File DestFile=new File(fileWithPath);

        //Copy file at destination

        FileUtils.copyFile(SrcFile, DestFile);


    }
}

//
//driver.get("https://edureka.co");
//        element_to_double_click = driver.find_element_by_xpath("//div[@class='container no-padding-xs hidden-xs']//h2[contains(text(),'Trending Courses')]")
//        actions = ActionChains(driver)
//        actions.double_click(element_to_double_click)
//        # perform the operation on the element
//        actions.perform()












