package sunithaworkspace.testcases;

import org.junit.Test;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import sunithaworkspace.pages.SeleniumPracticeFormPage;

public class CssSeletorTest {

    @Test
    public void runCSSSelectorTest() {
        System.setProperty("webdriver.chrome.driver", "C:/Users/16281/Downloads/chromedriver_win32/chromextract/chromedriver.exe");

        WebDriver driver = new ChromeDriver();
        driver.manage().window().maximize();
        driver.get("http://www.seleniumframework.com/Practiceform/");

        SeleniumPracticeFormPage spfPage = new SeleniumPracticeFormPage(driver);

        WebElement cssObject = spfPage.getCSSElement();

        System.out.println(cssObject.getText());

    }
}
