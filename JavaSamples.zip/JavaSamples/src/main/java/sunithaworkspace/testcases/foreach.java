package sunithaworkspace.testcases;

public class foreach {
}
