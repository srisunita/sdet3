package sunithaworkspace.testcases;

import org.junit.Test;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.interactions.Actions;
import sunithaworkspace.pages.SeleniumPracticeFormPage;

public class DragDropTest {

    @Test
    public void runDragDropTest(){
        System.setProperty("webdriver.chrome.driver", "C:/Users/16281/Downloads/chromedriver_win32/chromextract/chromedriver.exe");

        WebDriver driver = new ChromeDriver();
        driver.manage().window().maximize();
        driver.get("http://www.seleniumframework.com/Practiceform/");

        SeleniumPracticeFormPage spfPage = new SeleniumPracticeFormPage(driver);

        WebElement dragMe = spfPage.getDragMeElement();

        System.out.println(dragMe.getAttribute("draggable"));
        System.out.println(dragMe.getText());

        WebElement dragTo = spfPage.getDragToElement();

        Actions actions = new Actions(driver);
        actions.moveToElement(dragTo).build().perform();
        actions.dragAndDrop(dragMe, dragTo).build().perform();
        actions.clickAndHold(dragMe).pause(2000).moveToElement(dragTo).release().build().perform();

    }

}
