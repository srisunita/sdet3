//package sunithaworkspace;

//import org.openqa.selenium.By;
//import org.openqa.selenium.WebDriver;
//import org.openqa.selenium.WebElement;
//import org.openqa.selenium.interactions.Actions;

//public class UploadFile {

//    WebDriver driver;

//    public UploadFile(WebDriver dr) {
//        this.driver = dr;



//    //Find the element of upload button and send the path
//    WebElement element= drive
//    r.findElement(By.name("datafile"));
//    element.sendKeys("C:\Users\Easy\Desktop\testfile.txt");
//
//    //When to use Robo script
//
//    Web

//
//    Actions actions = new Actions(driver);



//}
