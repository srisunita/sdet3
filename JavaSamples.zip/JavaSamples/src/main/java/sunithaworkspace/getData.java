package sunithaworkspace;
import io.restassured.RestAssured;
import io.restassured.response.Response;
import org.apache.commons.logging.Log;
import org.junit.Assert;
import org.junit.Test;

public class getData {

     @Test
        public void getResponsecode(){

        Response resp = RestAssured.get("http://openweathermap.org/city/4252071");
        int code = resp.getStatusCode();
        System.out.println("status code is  "  +code);
        Assert.assertEquals(code,200 );

    }

//    @Test
//    public void submitForm() {
//        RestAssured.baseURI = "https://www.example.com";
//        given().urlEncodingEnabled(true)
//                .param("username", "user@site.com")
//                .param("password", "Pas54321")
//                .header("Accept", ContentType.JSON.getAcceptHeader())
//                .post("/login")
//                .then().statusCode(200);
//    }
//}

}

