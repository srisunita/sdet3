package sunithaworkspace;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

public class codepractice {

    public static <list> void main(String[] args) {
      List<String> veggies;
        veggies = new ArrayList<>(Arrays.asList("tomato","potato","carrot"));
        veggies.forEach((v) -> System.out.println(v));
       // System.out.println(veggies);


    }
}
