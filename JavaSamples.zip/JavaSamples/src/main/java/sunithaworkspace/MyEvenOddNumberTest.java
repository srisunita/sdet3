package sunithaworkspace;
import static org.junit.Assert.assertEquals;
import org.junit.Test;
import sunithaworkspace.MyEvenOddNumber;
public class MyEvenOddNumberTest {

    @Test
    public void TestEvenOddNumber() {
        MyEvenOddNumber eon = new MyEvenOddNumber();
        assertEquals("the value 10 is an even number", true, eon.isEvenNumber(10));
    }

}
