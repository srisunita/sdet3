package sunithaworkspace;

import org.apache.poi.openxml4j.exceptions.InvalidFormatException;
import org.apache.poi.ss.usermodel.*;

import java.io.File;
import java.io.IOException;
import java.math.BigDecimal;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;

//import org.json.simple.JSONObject;

public class ReadData {

    public static final String SAMPLE_XLSX_FILE_PATH = "src/main/resources/InputFiles/employee.xlsx";

    public static void main(String[] args) throws IOException, InvalidFormatException {

        // Creating a Workbook from an Excel file (.xls or .xlsx)
        Workbook workbook = WorkbookFactory.create(new File(SAMPLE_XLSX_FILE_PATH));

        // Retrieving the number of sheets in the Workbook
        System.out.println("Workbook has " + workbook.getNumberOfSheets() + " Sheets : ");
        // Getting the Sheet at index zero
        Sheet sheet = workbook.getSheetAt(0);

        // Create a DataFormatter to format and get each cell's value as String
        DataFormatter dataFormatter = new DataFormatter();

        // 1. You can obtain a rowIterator and columnIterator and iterate over them
        System.out.println("\n\nIterating over Rows and Columns using Iterator\n");
        Iterator<Row> rowIterator = sheet.rowIterator();
        while (rowIterator.hasNext()) {
            Row row = rowIterator.next();

            // Now let's iterate over the columns of the current row
            Iterator<Cell> cellIterator = row.cellIterator();

            while (cellIterator.hasNext()) {
                Cell cell = cellIterator.next();
                String cellValue = dataFormatter.formatCellValue(cell);
                System.out.print(cellValue + "\\\t");
            }
            System.out.println();

// Get first and last cell number.
            int firstCellNum = row.getFirstCellNum();
            int lastCellNum = row.getLastCellNum();


            // Create a String list to save column data in a row.
            List<String> rowDataList = new ArrayList<String>();

            // Loop in the row cells.
            String strCellValue;
            for (int j = firstCellNum; j < lastCellNum; j++) {
                // Get current cell.
                Cell cell = row.getCell(j);

                // Get cell type.
                int cellType = cell.getCellType();

                if (cellType == CellType.NUMERIC.getCode()) {
                    double numberValue = cell.getNumericCellValue();

                    // BigDecimal is used to avoid double value is counted use Scientific counting method.
                    // For example the original double variable value is 12345678, but jdk translated the value to 1.2345678E7.
                    String stringCellValue = BigDecimal.valueOf(numberValue).toPlainString();


                    rowDataList.add(stringCellValue);
                }


                // public static String getCellValueAsString(Cell cell){
                strCellValue = null;
                if (cell != null) {
                    switch (cell.getCellType()) {
                        case Cell.CELL_TYPE_STRING:
                            strCellValue = cell.toString();
                            break;
                        case Cell.CELL_TYPE_NUMERIC:
                            if (DateUtil.isCellDateFormatted(cell)) {
                                SimpleDateFormat dateFormat = new SimpleDateFormat(
                                        "dd/MM/yyyy");
                                strCellValue = dateFormat.format(cell.getDateCellValue());
                            } else {
                                Double value = cell.getNumericCellValue();
                                Long longValue = value.longValue();
                                strCellValue = new String(longValue.toString());
                            }
                            break;
                        case Cell.CELL_TYPE_BOOLEAN:
                            strCellValue = new String(new Boolean(
                                    cell.getBooleanCellValue()).toString());
                            break;
                        case Cell.CELL_TYPE_BLANK:
                            strCellValue = "";
                            break;
                    }
                }

                // Start constructing JSON.
                JSONObject json = new JSONObject();

                // Iterate through the rows.
                JSONArray rows = new JSONArray();
                for (Iterator<Row> rowsIT = sheet.rowIterator(); rowsIT.hasNext(); ) {
                    Row jrow = rowsIT.next();
                    JSONObject jRow = new JSONObject();

                    // Iterate through the cells.
                    JSONArray cells = new JSONArray();
                    for (Iterator<Cell> cellsIT = row.cellIterator(); cellsIT.hasNext(); ) {
                        Cell jcell = cellsIT.next();
                         jcell.getStringCellValue();
                    }
              //      jRow.toString("cell", cells);
               //     rows.toString(jrow);
                }

                // Create the JSON.
                json.toString("rows");

// Get the JSON text.
            //    return json.toString(jrows);
        }
        }
    }
}


