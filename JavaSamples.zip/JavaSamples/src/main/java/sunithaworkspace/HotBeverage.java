package sunithaworkspace;

public class HotBeverage {
    private static String note = "Hot Beverage";

    public static class HotTea {

        public void displayOutput() {
            System.out.println("hot tea says: " + note);
        }
    }



    public static void main(String[] args) {
    //create instance of static class

        HotBeverage.HotTea ht = new HotBeverage.HotTea();
  //call the method we created
        ht.displayOutput();
    }
}